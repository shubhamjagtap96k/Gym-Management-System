package com.gymmanagement.GymManagementSystemm;



import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.gymmanagement.GymManagementSystemm.entity.HealthStatus;
import com.gymmanagement.GymManagementSystemm.entity.RegistrationForm;
import com.gymmanagement.GymManagementSystemm.entity.dashboard;
import com.gymmanagement.GymManagementSystemm.entity.payments;

import org.hibernate.Session;

public class App  {

	
	    public static void main( String[] args )
	    {
	       Configuration conf=new Configuration().configure().addAnnotatedClass(RegistrationForm.class).addAnnotatedClass(dashboard.class).addAnnotatedClass(payments.class)
	    		   .addAnnotatedClass(HealthStatus.class);
	       SessionFactory ss=conf.buildSessionFactory();
	       Session s=ss.openSession();
	      Transaction t=s.beginTransaction();
	      RegistrationForm s1=new RegistrationForm(101,"shubham Jagtap","pune","male","23","9325301472","20/12/2023","25/08/2001");
	      RegistrationForm s2=new RegistrationForm(102,"Ganesh Erande","pune","male","22","8956321475","20/12/2023","15/03/2001");
	      dashboard d1=new dashboard(1500,1,3);
	      payments p1=new payments(101, "20/03/2024", "Shubham Jagtap","9325301472", "Male","Paid");
	      payments p2=new payments(102, "20/03/2024", "Ganesh Erande","8956321475", "Male","UnPaid"); 
	      HealthStatus h1=new HealthStatus(182,75.26,22.6,"Your BMI is Normal");
	      
	       s.save(s1);
	       s.save(s2);
	       s.save(d1);
	       s.save(p1);
	       s.save(p2);
	       s.save(h1);
	       t.commit();
	       s.close();
	       ss.close();
	       System.out.println("Welcome To Gym");
	    }
	    
	}

