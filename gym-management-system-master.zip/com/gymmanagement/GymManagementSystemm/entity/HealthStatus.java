package com.gymmanagement.GymManagementSystemm.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Health_Status")
public class HealthStatus {
	
	@Id
	private float height;
	private double weight;
	private double BodyMassIndex;
	private String Remarks;
	
	public HealthStatus(float height, double d, double e, String remarks) {
		super();
		this.height = height;
		this.weight = d;
		BodyMassIndex = e;
		Remarks = remarks;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public double getBodyMassIndex() {
		return BodyMassIndex;
	}
	public void setBodyMassIndex(float bodyMassIndex) {
		BodyMassIndex = bodyMassIndex;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}