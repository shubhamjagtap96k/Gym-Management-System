package com.gymmanagement.GymManagementSystemm.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Payments")
public class payments {

	
	
	@Id
	private int memberId;
	private String membershipExpiry;
	private String Name;
	private String phone;
	private String gender;
	private String Action;
	
	
	public payments(int memberId, String membershipExpiry, String name, String phone, String gender, String action) {
		super();
		this.memberId = memberId;
		this.membershipExpiry = membershipExpiry;
		Name = name;
		this.phone = phone;
		this.gender = gender;
		Action = action;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public String getMembershipExpiry() {
		return membershipExpiry;
	}
	public void setMembershipExpiry(String membershipExpiry) {
		this.membershipExpiry = membershipExpiry;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	
	
	
}