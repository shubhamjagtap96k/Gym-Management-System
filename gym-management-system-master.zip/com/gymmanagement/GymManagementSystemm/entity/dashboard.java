package com.gymmanagement.GymManagementSystemm.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DashBoard")
public class dashboard {

	
	
	@Id
	private int Income;
	private int TotalMembers;
	private int AvaialblePlans;
	
	public dashboard(int income, int totalMembers, int avaialblePlans) {
		super();
		Income = income;
		TotalMembers = totalMembers;
		AvaialblePlans = avaialblePlans;
	}
	public int getIncome() {
		return Income;
	}
	public void setIncome(int income) {
		Income = income;
	}
	public int getTotalMembers() {
		return TotalMembers;
	}
	public void setTotalMembers(int totalMembers) {
		TotalMembers = totalMembers;
	}
	public int getAvaialblePlans() {
		return AvaialblePlans;
	}
	public void setAvaialblePlans(int avaialblePlans) {
		AvaialblePlans = avaialblePlans;
	}
				
		
		}

		
	 
