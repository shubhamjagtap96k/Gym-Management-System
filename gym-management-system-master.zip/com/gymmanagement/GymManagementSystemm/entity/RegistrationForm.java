package com.gymmanagement.GymManagementSystemm.entity;

import javax.persistence.*;

@Entity
@Table(name = "registration_form")
public class RegistrationForm {
	@Id
		private int Memberid;
		private String name;
		private String city;
		private String age;
		private String gender;
		private String phoneNumber;
		private String joiningDate;
		private String DateofBirth;
		
		public RegistrationForm(int memberid, String name, String city, String age, String gender, String phoneNumber,
				String joiningDate, String dateofBirth) {
			super();
			Memberid = memberid;
			this.name = name;
			this.city = city;
			this.age = age;
			this.gender = gender;
			this.phoneNumber = phoneNumber;
			this.joiningDate = joiningDate;
			DateofBirth = dateofBirth;
		}
		public int getMemberid() {
			return Memberid;
		}
		public void setMemberid(int memberid) {
			Memberid = memberid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getAge() {
			return age;
		}
		public void setAge(String age) {
			this.age = age;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getJoiningDate() {
			return joiningDate;
		}
		public void setJoiningDate(String joiningDate) {
			this.joiningDate = joiningDate;
		}
		public String getDateofBirth() {
			return DateofBirth;
		}
		public void setDateofBirth(String dateofBirth) {
			DateofBirth = dateofBirth;
		}
		
		
	}

	
    

